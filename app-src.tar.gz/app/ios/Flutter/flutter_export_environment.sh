#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/tmp/flutter3.47.9"
export "FLUTTER_APPLICATION_PATH=/workspace/projects/3d170395-d8a4-43f8-8544-a59d34c759da/app"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/workspace/projects/3d170395-d8a4-43f8-8544-a59d34c759da/app/ios/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=9"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
